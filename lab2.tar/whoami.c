#define __LIBRARY__
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
_syscall2(int,whoami,char*,name,unsigned,size);
int main(void)
{
	char name[25] = {0};	
	whoami(name,24);
	printf("%s\n",name);
	return 0;
}

